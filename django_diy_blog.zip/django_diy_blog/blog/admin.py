from django.contrib import admin

from .models import BlogAuthor, Blog, BlogComment


#admin.site.register(BlogAuthor)
#admin.site.register(Blog)
admin.site.register(BlogComment)


class BlogAuthorAdmin(admin.ModelAdmin):
	list_display = ('user', 'bio','author_image')
	
admin.site.register(BlogAuthor, BlogAuthorAdmin)



class BlogAdmin(admin.ModelAdmin):
	list_display= ('title','updated','timestamp')
	list_display_link = ('title')
	list_filter = ["updated","timestamp"]

	class Meta:
		model = Blog
		
admin.site.register(Blog, BlogAdmin)


class BlogCommentAdmin(admin.ModelAdmin):
	list_display = ('id','comment_text','comment_date','blog')
	list_filter = ['comment_date']

		


