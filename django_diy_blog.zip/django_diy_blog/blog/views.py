from django.shortcuts import render, redirect
from django.views import generic
from django.views.generic import DetailView
from django.shortcuts import get_object_or_404, render
from .models import BlogAuthor, Blog, BlogComment
from .forms import RegistrationForm



def index(request):
	num_blog_author = BlogAuthor.objects.all().count()
	num_blog = Blog.objects.all().count()
	num_blog_comment = BlogComment.objects.all().count()
	
	
	context = {
		'page_title':'Index Page',
		'num_blog_author': num_blog_author,
		'num_blog': num_blog,
		'num_blog_comment': num_blog_comment,		
	}

	# Render the HTML template index.html with the data in the context variable
	return render(request,'index.html', context)

def register(request):
	context ={}
	if request.method == 'POST':
		form = RegistrationForm(request.POST)
		if form.is_valid():
			form.save()
			return redirect(reverse('author_create'))
			#return redirect(reverse('blog-authors'))
			#return reverse('blog-detail', kwargs={'pk': self.kwargs['pk'],})
	else:
		form = RegistrationForm()		
		context = {
			'page_title':'Register',
			'form':form 
		  }
	return render(request,'blog/register.html', context)
	
	
def about(request):
	post_lists = Blog.objects.all()
	context = {
		'page_title':'About',
		'posts': post_lists
	}
	
	return render(request,'blog/about.html', context)
	

def blog_author_detail(request, pk=None):
	blogauthor = get_object_or_404(BlogAuthor, pk=pk)
	context = {
		'blogauthor': blogauthor,
		'page_title': 'Blog Author Detail Page',
	}
	return render(request,'blog/blogauthor_detail_page.html ',context)
	
	
class BlogListView(generic.ListView):
	model = Blog
	paginate_by = 8

	
class BlogDetailView(generic.DetailView):
	model = Blog


	
class BlogAuthorListView(generic.ListView):
	model = BlogAuthor
	
	
#class BlogAuthorDetail(generic.DetailView):
	#model = BlogAuthor
	#template_name = 'blog/blogauthor_detail_page.html'


from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from .models import BlogAuthor


class BlogAuthorCreate(CreateView):
    model = BlogAuthor
    fields = '__all__'
   

class BlogAuthorUpdate(UpdateView):
	model = BlogAuthor
	fields = '__all__'

class BlogAuthorDelete(DeleteView):
    model = BlogAuthor
    success_url = reverse_lazy('authors')
	
	


from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic.edit import CreateView
from django.urls import reverse	

class BlogCommentCreate(LoginRequiredMixin, CreateView):
    """
    Form for adding a blog comment. Requires login. 
    """
    model = BlogComment
    fields = ['comment_text',]

    def get_context_data(self, **kwargs):
        """
        Add associated blog to form template so can display its title in HTML.
        """
        # Call the base implementation first to get a context
        context = super(BlogCommentCreate, self).get_context_data(**kwargs)
        # Get the blog from id and add it to the context
        context['blog'] = get_object_or_404(Blog, pk = self.kwargs['pk'])
        return context
        
    def form_valid(self, form):
        """
        Add author and associated blog to form data before setting it as valid (so it is saved to model)
        """
        #Add logged-in user as author of comment
        form.instance.author = self.request.user
        #Associate comment with blog based on passed id
        form.instance.blog=get_object_or_404(Blog, pk = self.kwargs['pk'])
        # Call super-class form validation behaviour
        return super(BlogCommentCreate, self).form_valid(form)

    def get_success_url(self): 
        """
        After posting comment return to associated blog.
        """
        return reverse('blog-detail', kwargs={'pk': self.kwargs['pk'],})