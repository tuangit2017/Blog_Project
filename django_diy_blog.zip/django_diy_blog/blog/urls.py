from django.conf.urls import url

from . import views


urlpatterns = [
	url(r'^$', views.index, name='index'),
	url(r'^register/$', views.register, name='register'),
	url(r'^about/$', views.about, name='about'),
	url(r'^blogs/$', views.BlogListView.as_view(), name='all-blogs'),
	url(r'^blog/(?P<pk>\d+)$', views.BlogDetailView.as_view(), name='blog-detail'),	
	# blog comment
	 url(r'^blog/(?P<pk>\d+)/comment/$', views.BlogCommentCreate.as_view(), name='blog_comment'),
	# list of author
	url(r'^authors/$', views.BlogAuthorListView.as_view(), name='blog-authors'),
	url(r'^author/(?P<pk>\d+)/$', views.blog_author_detail, name='blog-author-detail'),
	#url(r'^authors/(?P<pk>\d+)/$', views.BlogAuthorDetail.as_view(), name='blog-author-detail'),
	#CRUD author
	url(r'^author/create/$', views.BlogAuthorCreate.as_view(), name='author_create'),
    url(r'^author/(?P<pk>\d+)/update/$', views.BlogAuthorUpdate.as_view(), name='author_update'),
    url(r'^author/(?P<pk>\d+)/delete/$', views.BlogAuthorDelete.as_view(), name='author_delete'),
	]
	
